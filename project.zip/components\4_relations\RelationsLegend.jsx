export default function RelationsLegend() {
  return (
    <div className="mb-4 text-center">
      <h3 className="text-base sm:text-lg font-bold text-yellow-400 mb-1">⚖️ מטריצת יחסים ושנאות</h3>
      <div className="flex flex-wrap justify-center items-center gap-x-4 gap-y-1 text-xs text-gray-300">
        <div>
          <span className="text-green-300 font-bold">לחיצה רגילה:</span> שינוי הדדי סימטרי (+1)
        </div>
        <div className="hidden sm:inline text-gray-500">|</div>
        <div>
          <span className="text-yellow-300 font-bold">מחשב: ימני</span> /{' '}
          <span className="text-yellow-300 font-bold">טלפון: לחיצה ארוכה</span> ⬅️ דרופדאון א-סימטרי
        </div>
      </div>
    </div>
  );
}
