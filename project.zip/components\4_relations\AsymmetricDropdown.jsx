'use client';

import { useEffect, useRef } from 'react';

const OPTIONS = [
  { val: 1, label: '💚 1 - אהבה עמוקה', bg: 'hover:bg-green-950/80 text-green-400' },
  { val: 2, label: '🤝 2 - שותפות טובה', bg: 'hover:bg-emerald-900/60 text-emerald-300' },
  { val: 3, label: '🔹 3 - חיוב חלקי', bg: 'hover:bg-blue-900/50 text-blue-300' },
  { val: 4, label: '⚖️ 4 - ניטרלי', bg: 'hover:bg-gray-800 text-gray-300' },
  { val: 5, label: '⚠️ 5 - הסתייגות', bg: 'hover:bg-yellow-900/50 text-yellow-300' },
  { val: 6, label: '🛑 6 - חרם קשה', bg: 'hover:bg-orange-950/80 text-orange-400 font-bold' },
  { val: 7, label: '🔥 7 - חרם מוחלט (טאבו)', bg: 'hover:bg-red-950/80 text-red-400 font-bold' },
];

export default function AsymmetricDropdown({ target, fromParty, toParty, onSelect, onClose }) {
  const menuRef = useRef(null);

  useEffect(() => {
    const handleOutsideClick = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        onClose();
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('touchstart', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('touchstart', handleOutsideClick);
    };
  }, [onClose]);

  if (!target || !fromParty || !toParty) return null;

  return (
    <div
      ref={menuRef}
      style={{
        top: `${target.y + 6}px`,
        left: `${Math.min(window.innerWidth - 250, Math.max(12, target.x - 110))}px`,
      }}
      className="fixed z-50 w-60 bg-gray-900/95 backdrop-blur-md border border-yellow-500/70 rounded-xl shadow-2xl p-2 text-right rtl"
    >
      <div className="border-b border-gray-700/80 pb-2 mb-2 px-1">
        <span className="text-[10px] text-yellow-400 font-bold block">הגדרת יחס א-סימטרי חד-כיווני</span>
        <span className="text-xs text-white font-bold block truncate">
          {fromParty.name} ⬅️ {toParty.name}
        </span>
      </div>

      <div className="space-y-1 max-h-56 overflow-y-auto">
        {OPTIONS.map((opt) => (
          <button
            key={opt.val}
            onClick={() => {
              onSelect(opt.val);
              onClose();
            }}
            className={`w-full text-right px-3 py-1.5 rounded-lg text-xs transition cursor-pointer flex items-center justify-between ${opt.bg}`}
          >
            <span>{opt.label}</span>
          </button>
        ))}
      </div>

      <button
        onClick={onClose}
        className="w-full mt-2 text-center text-[11px] text-gray-400 hover:text-white py-1 border-t border-gray-800 cursor-pointer"
      >
        ביטול
      </button>
    </div>
  );
}
