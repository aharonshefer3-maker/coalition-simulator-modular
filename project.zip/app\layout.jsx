import './globals.css';

export const metadata = {
  title: 'קואליציאטור Next.js',
  description: 'סימולטור הרכבת ממשלה וקואליציות',
};

export default function RootLayout({ children }) {
  return (
    <html lang="he" dir="rtl">
      <body>{children}</body>
    </html>
  );
}