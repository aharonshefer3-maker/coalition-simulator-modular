// components/coalition/CoalitionCard.jsx
'use client';

import CoalitionBreakdown from './CoalitionBreakdown';

export default function CoalitionCard({ result, type }) {
  return (
    <div className="bg-white p-4 sm:p-6 rounded-2xl border border-sky-200 shadow-sm text-right transition hover:shadow-md">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 mb-4 pb-4 border-b border-sky-100">
        <span className="text-2xl sm:text-3xl font-black text-blue-900">
          {result.seats} <span className="text-base sm:text-lg font-normal text-slate-500">מנדטים</span>
        </span>
        <span className="text-slate-500 text-xs sm:text-sm font-medium">
          פער אידיאולוגי משוקלל: <strong className="text-slate-700">{result.gap}</strong>
        </span>
      </div>

      {type === 'normal' ? (
        <div className="flex flex-wrap gap-2">
          {result.parties.map((p) => (
            <span key={p.id} className="bg-sky-50 text-blue-900 border border-sky-200 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold shadow-2xs">
              {p.name} ({p.seats})
            </span>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          <CoalitionBreakdown
            brokenDetails={result.brokenDetails}
            taboosBroken={result.taboosBroken}
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-sky-50/70 p-4 rounded-xl border border-sky-200">
              <h3 className="font-bold text-blue-900 mb-2 text-sm sm:text-base">מחנה א' ({result.blocA.seats})</h3>
              <div className="flex flex-wrap gap-2">
                {result.blocA.parties.map((p) => (
                  <span key={p.id} className="bg-white text-blue-800 border border-sky-200 px-2.5 py-1 rounded-lg text-xs font-semibold">
                    {p.name}
                  </span>
                ))}
              </div>
            </div>
            <div className="bg-indigo-50/70 p-4 rounded-xl border border-indigo-200">
              <h3 className="font-bold text-indigo-950 mb-2 text-sm sm:text-base">מחנה ב' ({result.blocB.seats})</h3>
              <div className="flex flex-wrap gap-2">
                {result.blocB.parties.map((p) => (
                  <span key={p.id} className="bg-white text-indigo-900 border border-indigo-200 px-2.5 py-1 rounded-lg text-xs font-semibold">
                    {p.name}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}