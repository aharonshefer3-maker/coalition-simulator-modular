'use client';

import { useRef } from 'react';

const RELATION_SYMBOLS = {
  1: { symbol: '💚 1', label: 'אהבה עמוקה', bg: 'bg-green-950/60 text-green-400' },
  2: { symbol: '🤝 2', label: 'שותפות טובה', bg: 'bg-emerald-900/40 text-emerald-300' },
  3: { symbol: '🔹 3', label: 'חיוב חלקי', bg: 'bg-blue-900/30 text-blue-300' },
  4: { symbol: '⚖️ 4', label: 'ניטרלי', bg: 'bg-gray-800 text-gray-300' },
  5: { symbol: '⚠️ 5', label: 'הסתייגות', bg: 'bg-yellow-900/40 text-yellow-300' },
  6: { symbol: '🛑 6', label: 'חרם קשה', bg: 'bg-orange-950/60 text-orange-400 font-bold' },
  7: { symbol: '🔥 7', label: 'חרם מוחלט (טאבו)', bg: 'bg-red-950/60 text-red-400 font-bold' },
};

export default function RelationCell({ val, isAsym, onNormalClick, onOpenMenu }) {
  const config = RELATION_SYMBOLS[val] || RELATION_SYMBOLS[4];
  const timerRef = useRef(null);
  const isLongPressRef = useRef(false);

  const handleTouchStart = (e) => {
    isLongPressRef.current = false;
    timerRef.current = setTimeout(() => {
      isLongPressRef.current = true;
      if (navigator.vibrate) navigator.vibrate(40);
      const rect = e.currentTarget.getBoundingClientRect();
      onOpenMenu({
        x: rect.left + rect.width / 2,
        y: rect.bottom + window.scrollY,
      });
    }, 500);
  };

  const handleTouchMove = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  const handleTouchEnd = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  const handleContextMenu = (e) => {
    e.preventDefault();
    onOpenMenu({ x: e.clientX, y: e.clientY + window.scrollY });
  };

  const handleClick = () => {
    if (isLongPressRef.current) {
      isLongPressRef.current = false;
      return;
    }
    onNormalClick();
  };

  return (
    <td
      onClick={handleClick}
      onContextMenu={handleContextMenu}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onTouchMove={handleTouchMove}
      className={`border border-gray-700/80 p-1.5 sm:p-2.5 min-w-[46px] sm:min-w-[54px] h-[46px] sm:h-[54px] select-none cursor-pointer touch-manipulation transition-colors hover:brightness-125 text-center text-[11px] sm:text-xs font-bold ${config.bg} ${
        isAsym ? 'ring-2 ring-yellow-400 ring-inset' : ''
      }`}
      title={`${config.label} ${isAsym ? '(א-סימטרי)' : '(סימטרי)'} | שמאל/טאפ קצר: שינוי הדדי, ימין/לחיצה ארוכה: תפריט א-סימטרי`}
    >
      <span className="block leading-none">{config.symbol}</span>
      {isAsym && <span className="block text-[8px] sm:text-[9px] text-yellow-300 mt-0.5 leading-none">א-סימטרי</span>}
    </td>
  );
}
