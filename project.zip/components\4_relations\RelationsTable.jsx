// components/relations/RelationsTable.jsx
'use client';

import { useState } from 'react';

const ASYMMETRIC_OPTIONS = [
  { value: 7, label: '7 - וטו מוחלט' },
  { value: 6, label: '6 - איבה חריפה' },
  { value: 5, label: '5 - לא מתאימים' },
];

export default function RelationsTable({ parties, relations, asymmetricPairs, onSetRelation }) {
  const [modalData, setModalData] = useState(null);
  const [selectedAsymVal, setSelectedAsymVal] = useState(7);

  const handleOpenMenu = (p1, p2) => {
    setModalData({ fromParty: p1, toParty: p2 });
    setSelectedAsymVal(7);
  };

  const handleConfirmAsymmetric = () => {
    if (!modalData) return;
    onSetRelation(
      modalData.fromParty.id,
      modalData.toParty.id,
      Number(selectedAsymVal),
      'asymmetric'
    );
    setModalData(null);
  };

  const getCellColor = (val, isAsym) => {
    let base = 'bg-gray-800 text-gray-200 border-gray-700';
    if (val === 7) base = 'bg-red-950 text-red-200 border-red-600 font-bold';
    else if (val === 6) base = 'bg-orange-950 text-orange-200 border-orange-600 font-semibold';
    else if (val === 5) base = 'bg-amber-950 text-amber-200 border-amber-600 font-semibold';
    else if (val <= 2) base = 'bg-emerald-950 text-emerald-200 border-emerald-600';

    if (isAsym) {
      return `${base} ring-2 ring-yellow-400`;
    }
    return base;
  };

  return (
    <div 
      className="bg-gray-800 p-3 sm:p-6 rounded-xl shadow-lg border border-gray-700 relative"
      onClick={() => modalData && setModalData(null)}
    >
      {/* מקרא קטן */}
      <div className="flex flex-wrap items-center gap-3 mb-4 text-xs text-gray-300 bg-gray-900/60 p-3 rounded-lg border border-gray-700">
        <span className="font-bold text-yellow-400">💡 מקרא:</span>
        <span>קליק שמאלי = שינוי מחזורי (1-7) דו-סטרי</span>
        <span>|</span>
        <span>קליק ימני = הגדרת וטו / איבה חד-כיווני (א-סימטרי)</span>
      </div>

      <div className="overflow-x-auto rounded-lg border border-gray-700 shadow-inner max-w-full">
        <table className="w-full text-center border-collapse">
          <thead>
            <tr>
              <th className="sticky right-0 z-20 p-2 sm:p-3 border border-gray-700 bg-gray-900 text-[11px] sm:text-xs text-yellow-300 font-bold whitespace-nowrap shadow-md min-w-[100px] sm:min-w-[120px]">
                המחרים ↓ \ המוחרם ←
              </th>
              {parties.map((p) => (
                <th
                  key={p.id}
                  className="p-1.5 sm:p-2 border border-gray-700 text-xs font-bold w-12 sm:w-14 h-28 sm:h-36 bg-gray-900 text-purple-300 align-bottom relative"
                >
                  <span
                    className="absolute bottom-2 right-1/2 translate-x-1/2 whitespace-nowrap text-[10px] sm:text-xs"
                    style={{ writingMode: 'vertical-rl' }}
                  >
                    {p.name}
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {parties.map((p1) => (
              <tr key={p1.id}>
                <th className="sticky right-0 z-10 p-2 border border-gray-700 whitespace-nowrap text-xs text-right bg-gray-900 text-blue-300 font-bold shadow-md">
                  {p1.name}
                </th>

                {parties.map((p2) => {
                  if (p1.id === p2.id) {
                    return <td key={p2.id} className="border border-gray-700 bg-gray-700/60" />;
                  }

                  const isAsym = Boolean(asymmetricPairs[`${p1.id}-${p2.id}`]);
                  const val = isAsym
                    ? relations[`${p1.id}-${p2.id}`] ?? 4
                    : relations[`${p1.id}-${p2.id}`] ?? relations[`${p2.id}-${p1.id}`] ?? 4;

                  const nextVal = val >= 7 ? 1 : val + 1;

                  return (
                    <td
                      key={p2.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        setModalData(null);
                        onSetRelation(p1.id, p2.id, nextVal, 'normal');
                      }}
                      onContextMenu={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        handleOpenMenu(p1, p2);
                      }}
                      className={`p-2 border border-gray-700 text-center cursor-pointer transition select-none active:scale-95 ${getCellColor(
                        val,
                        isAsym
                      )}`}
                      title="קליק שמאלי: שינוי סימטרי | קליק ימני: א-סימטרי"
                    >
                      <div className="font-bold text-sm">{val}</div>
                      {isAsym && (
                        <div className="text-[9px] text-yellow-300 font-normal">
                          א-סימטרי
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* דיאלוג מרכזי לקליק ימני (סגור תמיד כברירת מחדל) */}
      {modalData && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="bg-gray-900 border-2 border-yellow-500/80 rounded-2xl w-full max-w-sm p-5 shadow-2xl text-right animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-base sm:text-lg font-bold text-yellow-400 mb-1">
              ⚡ הגדרת יחס א-סימטרי (חד-כיווני)
            </h3>
            <p className="text-xs text-gray-300 mb-4">
              עמדת <span className="text-blue-400 font-bold">{modalData.fromParty.name}</span> כלפי{' '}
              <span className="text-purple-300 font-bold">{modalData.toParty.name}</span>:
            </p>

            <div className="mb-5">
              <label className="block text-xs font-semibold text-gray-300 mb-2">
                בחר רמת וטו / איבה:
              </label>
              <select
                value={selectedAsymVal}
                onChange={(e) => setSelectedAsymVal(Number(e.target.value))}
                className="w-full bg-black border border-yellow-500/70 text-yellow-300 font-bold rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400 cursor-pointer"
              >
                {ASYMMETRIC_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value} className="bg-gray-900 text-white">
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleConfirmAsymmetric}
                className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 rounded-xl text-sm transition cursor-pointer active:scale-95 shadow"
              >
                שמור יחס חד-כיווני
              </button>
              <button
                onClick={() => setModalData(null)}
                className="flex-1 bg-gray-700 hover:bg-gray-600 text-gray-300 font-semibold py-2.5 rounded-xl text-sm transition cursor-pointer active:scale-95"
              >
                ביטול
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}