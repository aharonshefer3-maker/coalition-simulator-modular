export function calcDistance(p1, p2) {
  if (!p1.pos || !p2.pos) return 0;
  let sum = 0;
  let count = 0;
  const maxLen = Math.max(p1.pos.length, p2.pos.length);
  for (let i = 0; i < maxLen; i++) {
    const v1 = Number(p1.pos[i]) ?? 4;
    const v2 = Number(p2.pos[i]) ?? 4;
    sum += Math.abs(v1 - v2);
    count++;
  }
  return count > 0 ? Number((sum / count).toFixed(2)) : 0;
}

export function findCoalitions(parties, relations) {
  const activeParties = parties.filter(p => Number(p.seats) > 0);

  const getRelation = (id1, id2) => {
    if (id1 === id2) return 1;
    return relations[`${id1}-${id2}`] ?? relations[`${id2}-${id1}`] ?? 4; 
  };

  const getCombinations = (arr) => {
    let result = [];
    const f = (prefix, arr) => {
      for (let i = 0; i < arr.length; i++) {
        const newPrefix = [...prefix, arr[i]];
        
        let hasTaboo = false;
        for (let p1 of newPrefix) {
          for (let p2 of newPrefix) {
            if (p1.id !== p2.id) {
              if (getRelation(p1.id, p2.id) === 7 || getRelation(p2.id, p1.id) === 7) {
                hasTaboo = true;
              }
            }
          }
        }

        if (!hasTaboo) {
          result.push(newPrefix);
          f(newPrefix, arr.slice(i + 1));
        }
      }
    };
    f([], arr);
    return result;
  };

  const allCombs = getCombinations(activeParties);
  let validCoalitions = [];

  // שלב 1: ממשלה טבעית (61+)
  allCombs.forEach(coalition => {
    const seats = coalition.reduce((s, p) => s + (Number(p.seats) || 0), 0);
    if (seats >= 61) {
      let totalGap = 0, pairs = 0;
      for (let i = 0; i < coalition.length; i++) {
        for (let j = i + 1; j < coalition.length; j++) {
          totalGap += calcDistance(coalition[i], coalition[j]);
          pairs++;
        }
      }
      validCoalitions.push({
        parties: coalition,
        seats,
        gap: pairs > 0 ? (totalGap / pairs).toFixed(2) : 0
      });
    }
  });

  if (validCoalitions.length > 0) {
    validCoalitions.sort((a, b) => a.gap - b.gap);
    return { type: 'normal', results: validCoalitions.slice(0, 5) };
  }

  // שלב 2: ממשלות פריטטיות (בלוקים שווים) עם משקלי שנאות
  let parityCoalitions = [];
  const validBlocs = allCombs.map(bloc => ({
    parties: bloc,
    seats: bloc.reduce((s, p) => s + (Number(p.seats) || 0), 0)
  })).filter(b => b.seats >= 30);

  for (let i = 0; i < validBlocs.length; i++) {
    for (let j = i + 1; j < validBlocs.length; j++) {
      const blocA = validBlocs[i];
      const blocB = validBlocs[j];

      if (blocA.seats !== blocB.seats) continue;
      if (blocA.seats + blocB.seats < 60) continue;

      const overlap = blocA.parties.some(pa => blocB.parties.some(pb => pa.id === pb.id));
      if (overlap) continue;

      let tabooScore = 0;
      let brokenDetails = [];
      let totalGap = 0;
      let pairs = 0;

      for (let pa of blocA.parties) {
        for (let pb of blocB.parties) {
          const rAB = getRelation(pa.id, pb.id);
          const rBA = getRelation(pb.id, pa.id);

          [ [pa, pb, rAB], [pb, pa, rBA] ].forEach(([fromP, toP, val]) => {
            if (val === 7) {
              tabooScore += 2;
              brokenDetails.push(`${fromP.name} בחרם רמה 7 על ${toP.name} (משקל 2)`);
            } else if (val === 6) {
              tabooScore += 1;
              brokenDetails.push(`${fromP.name} בחרם רמה 6 על ${toP.name} (משקל 1)`);
            } else if (val === 5) {
              tabooScore += 0.66;
              brokenDetails.push(`${fromP.name} בחרם רמה 5 על ${toP.name} (משקל 0.66)`);
            }
          });

          totalGap += calcDistance(pa, pb);
          pairs++;
        }
      }

      const avgGap = pairs > 0 ? totalGap / pairs : 0;

      if (tabooScore <= 4 && avgGap < 16) {
        parityCoalitions.push({
          blocA,
          blocB,
          seats: blocA.seats + blocB.seats,
          taboosBroken: Number(tabooScore.toFixed(2)),
          brokenDetails,
          gap: avgGap.toFixed(2)
        });
      }
    }
  }

  parityCoalitions.sort((a, b) => a.taboosBroken - b.taboosBroken || a.gap - b.gap);
  return { type: 'parity', results: parityCoalitions.slice(0, 5) };
}
