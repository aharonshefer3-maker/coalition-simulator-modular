'use client';

export default function PartyCard({ party, onSeatChange, onDelete }) {
  return (
    <div className="bg-gray-700 p-3 sm:p-4 rounded-lg flex justify-between items-center group">
      <div className="flex items-center gap-2 overflow-hidden">
        {onDelete && (
          <button
            onClick={() => onDelete(party.id)}
            title="מחק מפלגה"
            className="text-gray-400 hover:text-red-400 transition text-sm cursor-pointer p-1"
          >
            🗑️
          </button>
        )}
        <span className="font-bold text-xs sm:text-sm truncate">{party.name}</span>
      </div>
      <input
        type="number"
        value={party.seats}
        onChange={(e) => onSeatChange(party.id, e.target.value)}
        onFocus={(e) => e.target.select()}
        className="w-14 sm:w-16 bg-gray-900 text-white border border-gray-600 rounded p-1 text-center font-bold text-sm"
      />
    </div>
  );
}
