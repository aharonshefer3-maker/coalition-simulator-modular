// components/position/PositionProfileEditor.jsx
'use client';

import { ISSUE_AXES } from '@/data/parties';

// רכיב סליידר פנימי עצמאי (פותר את שגיאת הייבוא)
function IssueAxisSliderInternal({ axis, value, onChange }) {
  return (
    <div className="bg-gray-800/60 border border-gray-700/70 p-3 sm:p-4 rounded-xl">
      <div className="flex justify-between items-center mb-2">
        <span className="text-xs sm:text-sm font-bold text-blue-300">
          {axis.name}
        </span>
        <span className="text-xs font-bold px-2 py-0.5 rounded bg-blue-900/60 text-blue-200 border border-blue-500/30">
          ערך: {value}
        </span>
      </div>

      <input
        type="range"
        min="1"
        max="5"
        step="1"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-blue-500 cursor-pointer h-2 bg-gray-700 rounded-lg appearance-none"
      />

      <div className="flex justify-between text-[11px] text-gray-400 mt-1.5 select-none">
        <span>{axis.leftLabel || '1 (ימין/התנגדות)'}</span>
        <span>{axis.rightLabel || '5 (שמאל/תמיכה)'}</span>
      </div>
    </div>
  );
}

export default function PositionProfileEditor({
  profileValues,
  onAxisChange,
  title,
  subtitle,
}) {
  return (
    <div className="bg-gray-800 border border-gray-700 rounded-2xl p-4 sm:p-5 shadow-lg space-y-4 text-right">
      {title && (
        <div className="border-b border-gray-700/80 pb-2">
          <h3 className="text-sm sm:text-base font-bold text-white">{title}</h3>
          {subtitle && <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
        {ISSUE_AXES.map((axis, index) => (
          <IssueAxisSliderInternal
            key={axis.id || index}
            axis={axis}
            value={profileValues[index] ?? 3}
            onChange={(val) => onAxisChange(index, val)}
          />
        ))}
      </div>
    </div>
  );
}