'use client';

import CoalitionCard from './CoalitionCard';

export default function CoalitionEngineRunner({ onRun, searchOutput, is120 }) {
  return (
    <div className="text-center">
      <button
        onClick={onRun}
        disabled={!is120}
        className={`w-full sm:w-auto text-xl sm:text-2xl font-bold py-4 sm:py-6 px-8 sm:px-12 rounded-2xl shadow-2xl transition transform hover:scale-105 ${
          is120
            ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white cursor-pointer'
            : 'bg-gray-700 text-gray-500 cursor-not-allowed'
        }`}
      >
        הקם ממשלה עכשיו! 🇮🇱
      </button>

      {searchOutput && searchOutput.results.length === 0 && (
        <div className="mt-8 text-lg sm:text-xl text-red-400 bg-red-900/30 p-6 rounded-lg border border-red-800">
          לא נמצאה אף היתכנות מתמטית לממשלה עקב חרמים קיצוניים.
        </div>
      )}

      {searchOutput && searchOutput.results.length > 0 && (
        <div className="mt-8 sm:mt-12 text-right">
          <h2 className="text-xl sm:text-2xl font-bold mb-6 text-blue-300">
            {searchOutput.type === 'parity'
              ? '⚠️ נוהל חירום: ממשלות פריטטיות (משוקללות לפי דרגות השנאה)'
              : '✨ ממשלות טבעיות (ללא חרמות)'}
          </h2>
          <div className="grid gap-4 sm:gap-6">
            {searchOutput.results.map((res, idx) => (
              <CoalitionCard key={idx} result={res} type={searchOutput.type} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
