'use client';

import PartyCard from './PartyCard';

export default function PartyList({ parties, onSeatChange, onDeleteParty }) {
  return (
    <div className="bg-gray-800 p-4 sm:p-6 rounded-xl shadow-lg border border-gray-700">
      <h3 className="text-xs sm:text-sm font-semibold text-gray-400 mb-4">
        רשימת המפלגות הפעילות (סה"כ: {parties.length} מפלגות):
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        {parties.map((p) => (
          <PartyCard
            key={p.id}
            party={p}
            onSeatChange={onSeatChange}
            onDelete={onDeleteParty}
          />
        ))}
      </div>
    </div>
  );
}
