// components/issue/IssueAxisSlider.jsx
'use client';

export default function IssueAxisSlider({ axis, value, onChange, disabled = false }) {
  const currentVal = value ?? 4;

  return (
    <div className="bg-white p-3.5 rounded-xl border border-sky-200 shadow-2xs flex flex-col justify-between transition hover:shadow-sm">
      <div className="flex justify-between items-center mb-1.5 text-xs">
        <span className="font-bold text-blue-900">{axis.label}</span>
        <span className="bg-sky-100 text-blue-800 px-2.5 py-0.5 rounded-lg font-black border border-sky-200">
          ערך: {currentVal}
        </span>
      </div>

      <input
        type="range"
        min="1"
        max="7"
        step="1"
        disabled={disabled}
        value={currentVal}
        onChange={(e) => onChange(Number(e.target.value))}
        className="accent-blue-600 cursor-pointer w-full my-2 disabled:opacity-50 h-2 bg-sky-100 rounded-lg appearance-none"
      />

      <div className="flex justify-between text-[11px] font-semibold">
        <span className="text-emerald-700">{axis.left}</span>
        <span className="text-rose-700">{axis.right}</span>
      </div>
    </div>
  );
}