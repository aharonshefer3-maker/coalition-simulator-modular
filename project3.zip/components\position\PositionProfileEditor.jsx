// components/position/PositionProfileEditor.jsx
'use client';

import { ISSUE_AXES } from '@/data/parties';

export default function PositionProfileEditor({ party, onUpdatePosition }) {
  // אם party הוא undefined או null, לא מרנדרים כלום ומונעים את קריסת האפליקציה
  if (!party) return null;

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-sky-200">
      <h3 className="text-lg font-extrabold text-slate-800 mb-4">
        {party.name} ({party.seats} מנדטים)
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {ISSUE_AXES.map((axis) => {
          const currentVal = party.pos?.[axis.id] ?? 4;

          return (
            <div key={axis.id} className="bg-sky-50/60 p-4 rounded-xl border border-sky-100 flex flex-col justify-between">
              <div className="flex justify-between items-center mb-2">
                <span className="font-bold text-sky-900 text-xs sm:text-sm">{axis.label}</span>
                <span className="bg-white text-sky-800 border border-sky-200 px-2.5 py-0.5 rounded-lg text-xs font-black shadow-2xs">
                  ערך: {currentVal}
                </span>
              </div>

              <input
                type="range"
                min="1"
                max="7"
                step="1"
                value={currentVal}
                onChange={(e) => onUpdatePosition?.(party.id, axis.id, Number(e.target.value))}
                className="accent-sky-600 cursor-pointer w-full my-2"
              />

              <div className="flex justify-between text-[11px] font-semibold text-slate-500">
                <span className="text-emerald-700">{axis.left}</span>
                <span className="text-rose-700">{axis.right}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}