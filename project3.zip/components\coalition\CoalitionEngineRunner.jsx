// components/5_coalition/CoalitionEngineRunner.jsx
'use client';

import { useMemo } from 'react';
import { findBestCoalitions } from '@/utils/coalitionEngine';
import CoalitionCard from './CoalitionCard';

export default function CoalitionEngineRunner({ parties, relations, asymmetricPairs }) {
  // הרצת החישוב בכל פעם שחל שינוי בעמדות המפלגות או ביחסי החרם
  const coalitions = useMemo(() => {
    return findBestCoalitions(parties, relations, asymmetricPairs, 61);
  }, [parties, relations, asymmetricPairs]);

  return (
    <div className="space-y-4">
      <div className="bg-sky-50 p-4 rounded-2xl border border-sky-200 flex justify-between items-center">
        <div>
          <h2 className="text-base font-extrabold text-sky-950">שילובי ממשלה אפשריים (61+ מנדטים)</h2>
          <p className="text-xs text-sky-700 mt-0.5">
            ממוינים לפי סכום הפערים האידיאולוגי הנמוך ביותר (ללא חרמות ווטו)
          </p>
        </div>
        <span className="bg-white text-sky-900 border border-sky-300 px-3 py-1 rounded-xl font-black text-xs">
          נמצאו {coalitions.length} שילובים
        </span>
      </div>

      {coalitions.length === 0 ? (
        <div className="bg-white p-8 rounded-2xl border border-dashed border-slate-300 text-center text-slate-500 text-sm">
          לא נמצאה אף קואליציה של 61 מנדטים ללא חרמות. נסה למתן יחסי וטו בטבלה.
        </div>
      ) : (
        <div className="space-y-3">
          {coalitions.slice(0, 20).map((coalition, idx) => (
            <CoalitionCard key={coalition.id} coalition={coalition} rank={idx + 1} />
          ))}
        </div>
      )}
    </div>
  );
}