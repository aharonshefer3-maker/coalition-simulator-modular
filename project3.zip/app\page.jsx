// app/page.jsx
'use client';

import { useState } from 'react';
import { INITIAL_PARTIES, INITIAL_RELATIONS } from '@/data/parties';
import { findBestCoalitions } from '@/utils/coalitionEngine';
// import { findCoalitions } from '@/utils/coalitionEngine';

import PartyList from '@/components/party/PartyList';
import CreatePartyForm from '@/components/party/CreatePartyForm';
import PositionProfileEditor from '@/components/position/PositionProfileEditor';
import RelationsTable from '@/components/relations/RelationsTable';
import CoalitionEngineRunner from '@/components/coalition/CoalitionEngineRunner';

export default function Home() {

  
  
  const [parties, setParties] = useState(INITIAL_PARTIES);
  const [relations, setRelations] = useState(INITIAL_RELATIONS);
  const [asymmetricPairs, setAsymmetricPairs] = useState({
    'likud-raam': true,
    'demokratim-shas': true,
    'demokratim-yahadut_hatorah': true,
  });

  const [activeTab, setActiveTab] = useState('parties');
  const [searchOutput, setSearchOutput] = useState(null);
  const [isAddFormOpen, setIsAddFormOpen] = useState(false);

  const totalSeats = parties.reduce(
    (sum, p) => sum + (p.seats === '' || p.seats == null ? 0 : Number(p.seats)),
    0
  );
  const handleUpdatePartyPosition = (partyId, axisIndex, newValue) => {
  setParties(prevParties =>
    prevParties.map(party => {
      if (party.id === partyId) {
        const newPos = [...party.pos];
        newPos[axisIndex] = newValue;
        return { ...party, pos: newPos };
      }
      return party;
    })
  );
};
  const is120 = totalSeats === 120;

  const handleSeatChange = (id, value) => {
    const newSeats = value === '' ? '' : Number(value);
    setParties(parties.map((p) => (p.id === id ? { ...p, seats: newSeats } : p)));
  };

  const handlePositionChange = (partyId, posIndex, value) => {
    setParties(parties.map((p) => {
      if (p.id === partyId) {
        const newPos = [...p.pos];
        newPos[posIndex] = Number(value);
        return { ...p, pos: newPos };
      }
      return p;
    }));
  };
  

  const handleAddNewParty = (newParty) => {
    setParties((prev) => [...prev, newParty]);
    setRelations((prev) => {
      const updated = { ...prev };
      parties.forEach((p) => {
        updated[`${newParty.id}-${p.id}`] = 4;
        updated[`${p.id}-${newParty.id}`] = 4;
      });
      return updated;
    });
  };

  const handleDeleteParty = (partyId) => {
    if (!confirm('האם אתה בטוח שברצונך למחוק מפלגה זו?')) return;
    setParties((prev) => prev.filter((p) => p.id !== partyId));
    setRelations((prev) => {
      const updated = { ...prev };
      Object.keys(updated).forEach((k) => {
        if (k.startsWith(`${partyId}-`) || k.endsWith(`-${partyId}`)) delete updated[k];
      });
      return updated;
    });
  };

  const setRelation = (id1, id2, val, actionType = 'normal') => {
    if (actionType === 'asymmetric') {
      setAsymmetricPairs((prev) => ({ ...prev, [`${id1}-${id2}`]: true }));
      setRelations((prev) => ({ ...prev, [`${id1}-${id2}`]: val }));
    } else {
      setAsymmetricPairs((prev) => {
        const updated = { ...prev };
        delete updated[`${id1}-${id2}`];
        delete updated[`${id2}-${id1}`];
        return updated;
      });
      setRelations((prev) => ({
        ...prev,
        [`${id1}-${id2}`]: val,
        [`${id2}-${id1}`]: val,
      }));
    }
  };

  const handleExportData = () => {
    const dataToExport = { parties, relations, asymmetricPairs };
    const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'coalition-state.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportData = (event) => {
    const file = event.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const imported = JSON.parse(e.target.result);
        if (imported.parties) setParties(imported.parties);
        if (imported.relations) setRelations(imported.relations);
        if (imported.asymmetricPairs) setAsymmetricPairs(imported.asymmetricPairs);
        alert('הנתונים נטענו בהצלחה!');
      } catch (err) {
        alert('שגיאה בקריאת הקובץ. וודא שהוא תקין.');
      }
    };
    reader.readAsText(file);
  };

const handleRun = () => {
    // 1. ניקוי וסינון מפלגות תקינות עם מושבים מעל 0
    const sanitizedParties = (parties || []).map((p) => ({
      ...p,
      seats: p.seats === '' || p.seats == null ? 0 : Number(p.seats),
    })).filter((p) => p.seats > 0);

    // בדיקת סך מושבים מינימלי להקמת ממשלה (מעל 61)
    const currentTotalSeats = sanitizedParties.reduce((sum, p) => sum + p.seats, 0);
    if (currentTotalSeats < 61) {
      alert(`סך המנדטים שהוזנו (${currentTotalSeats}) קטן מ-61, לא ניתן להרכיב קואליציה.`);
      return;
    }

    // 2. הפעלת מנוע החישוב (כולל relations ו-asymmetricPairs)
    const results = findCoalitions(sanitizedParties, relations, asymmetricPairs);
    setSearchOutput(results);
  };

  return (
    <main dir="rtl" className="min-h-screen bg-sky-50/60 text-slate-800 p-3 sm:p-6 font-sans">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* כותרת עליונה */}
        <header className="bg-white border border-sky-200 rounded-2xl p-6 shadow-sm text-center">
          <h1 className="text-2xl sm:text-4xl font-extrabold text-sky-900 mb-2">
            קואליציאטור Next.js 🗳️
          </h1>
          <p className="text-xs sm:text-sm text-slate-600">
            סימולטור הרכבת ממשלה על פי 6 צירי עמדות וטבלת שנאות
          </p>

          <div className="mt-4 inline-block">
            <span className={`px-4 py-1.5 rounded-full font-bold text-sm border shadow-xs ${
              is120 
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300' 
                : 'bg-rose-50 text-rose-700 border-rose-300'
            }`}>
              סה"כ מנדטים: {totalSeats} / 120
              {!is120 && <span className="mr-2">⚠️ חובה לאזן ל-120</span>}
            </span>
          </div>
        </header>

        {/* כפתורי שמירה וטעינה */}
        <div className="flex justify-center gap-3 sm:gap-4 flex-wrap">
          <button 
            onClick={handleExportData}
            className="bg-white hover:bg-sky-50 text-sky-700 border border-sky-300 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-xs transition flex items-center gap-2 cursor-pointer"
          >
            📥 שמור מצב (JSON)
          </button>

          <label className="bg-white hover:bg-sky-50 text-sky-700 border border-sky-300 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-xs transition flex items-center gap-2 cursor-pointer">
            📤 טען מצב (JSON)
            <input type="file" accept=".json" onChange={handleImportData} className="hidden" />
          </label>
        </div>

        {/* סרגל טאבים בתכלת-כחול */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-3 bg-white p-2 rounded-2xl border border-sky-200 shadow-xs">
          {[
            { id: 'parties', label: 'מנדטים (סקר)' },
            { id: 'positions', label: 'עמדות פוליטיות (6 צירים)' },
            { id: 'relations', label: 'טבלת שנאות ויחסים' },
            { id: 'algorithm', label: 'הרכב ממשלה' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-sky-600 text-white shadow-md'
                  : 'text-slate-600 hover:text-sky-700 hover:bg-sky-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* טאב 1: מפלגות */}
        {activeTab === 'parties' && (
          <div className="space-y-4">
            <div className="flex justify-start">
              <button
                onClick={() => setIsAddFormOpen(!isAddFormOpen)}
                className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-4 py-2.5 rounded-xl text-xs sm:text-sm transition flex items-center gap-2 cursor-pointer shadow-sm"
              >
                <span>{isAddFormOpen ? '✖️ סגור טופס' : '➕ הקמת מפלגה חדשה'}</span>
              </button>
            </div>

            <CreatePartyForm
              isOpen={isAddFormOpen}
              onClose={() => setIsAddFormOpen(false)}
              onAddParty={handleAddNewParty}
            />

            <PartyList
              parties={parties}
              onSeatChange={handleSeatChange}
              onDeleteParty={handleDeleteParty}
            />
          </div>
        )}

        {/* טאב 2: עמדות */}
        {activeTab === 'positions' && (
          <div className="space-y-4">
          {parties && parties.filter(Boolean).map((party) => (
           <PositionProfileEditor
            key={party.id}
               party={party}
             onUpdatePosition={handleUpdatePartyPosition}
             />
          ))}
          </div>
        )}

        {/* טאב 3: טבלת יחסים ושנאות */}
        {activeTab === 'relations' && (
          <RelationsTable
            parties={parties}
            relations={relations}
            asymmetricPairs={asymmetricPairs}
            onSetRelation={setRelation}
          />
        )}

        {/* טאב 4: הרכבת ממשלה */}
        {activeTab === 'algorithm' && (
          <CoalitionEngineRunner
            onRun={handleRun}
            searchOutput={searchOutput}
            is120={is120}
          />
        )}

      </div>
    </main>
  );
}