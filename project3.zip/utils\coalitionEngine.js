// utils/coalitionEngine.js

/**
 * חישוב מרחק מנהטן ממוצע לאורך צירי העמדות
 */
export function calcDistance(p1, p2) {
  if (!p1?.pos || !p2?.pos) return 0;
  let sum = 0;
  const len = Math.min(p1.pos.length, p2.pos.length);
  for (let i = 0; i < len; i++) {
    const v1 = Number(p1.pos[i]) ?? 4;
    const v2 = Number(p2.pos[i]) ?? 4;
    sum += Math.abs(v1 - v2);
  }
  return len > 0 ? Number((sum / len).toFixed(2)) : 0;
}

/**
 * חישוב פערים מצטבר בתוך קואליציה
 */
function calculateCoalitionIdeology(parties) {
  let totalGap = 0;
  let pairs = 0;
  for (let i = 0; i < parties.length; i++) {
    for (let j = i + 1; j < parties.length; j++) {
      totalGap += calcDistance(parties[i], parties[j]);
      pairs++;
    }
  }
  const avgGap = pairs > 0 ? Number((totalGap / pairs).toFixed(2)) : 0;
  return { totalGap: Number(totalGap.toFixed(2)), avgGap, pairs };
}

/**
 * מנוע חיפוש: שלב 1 קואליציה הומוגנית (61+), ושלב 2 ממשלה פריטטית של 2 גושים
 */
export function findBestCoalitions(parties = [], relations = {}, asymmetricPairs = {}) {
  const activeParties = (parties || []).filter((p) => Number(p.seats) > 0);

  const getRelation = (id1, id2) => {
    if (id1 === id2) return 1;
    return (
      relations[`${id1}-${id2}`] ??
      relations[`${id2}-${id1}`] ??
      relations[`${id1}_${id2}`] ??
      relations[`${id2}_${id1}`] ??
      4
    );
  };

  // יצירת תתי-קבוצות ללא חרם רמה 7
  const getCleanCombinations = (arr) => {
    const result = [];
    const f = (prefix, remaining) => {
      for (let i = 0; i < remaining.length; i++) {
        const nextParty = remaining[i];

        let hasTaboo = false;
        for (const p of prefix) {
          if (getRelation(p.id, nextParty.id) >= 7 || getRelation(nextParty.id, p.id) >= 7) {
            hasTaboo = true;
            break;
          }
        }

        if (!hasTaboo) {
          const newPrefix = [...prefix, nextParty];
          result.push(newPrefix);
          f(newPrefix, remaining.slice(i + 1));
        }
      }
    };
    f([], arr);
    return result;
  };

  const allCombs = getCleanCombinations(activeParties);

  // ==========================================
  // שלב 1: ממשלה רגילה אחת (61+ מנדטים)
  // ==========================================
  const naturalCoalitions = [];

  for (const coalition of allCombs) {
    const seats = coalition.reduce((sum, p) => sum + (Number(p.seats) || 0), 0);
    if (seats >= 61) {
      const { avgGap, totalGap } = calculateCoalitionIdeology(coalition);

      naturalCoalitions.push({
        id: coalition.map((p) => p.id).sort().join('-'),
        parties: coalition,
        seats,
        totalSeats: seats,
        gap: avgGap,
        totalDistance: totalGap,
        averageDistance: avgGap,
        isParity: false,
      });
    }
  }

  if (naturalCoalitions.length > 0) {
    naturalCoalitions.sort((a, b) => a.gap - b.gap);
    const results = naturalCoalitions.slice(0, 20);
    results.type = 'normal';
    results.results = results;
    return results;
  }

  // ==========================================
  // שלב 2: ממשלה פריטטית של 2 גושים (אם אין ממשלה טבעית)
  // ==========================================
  const parityCoalitions = [];
  const validBlocs = allCombs
    .map((bloc) => ({
      parties: bloc,
      seats: bloc.reduce((sum, p) => sum + (Number(p.seats) || 0), 0),
    }))
    .filter((b) => b.seats >= 28);

  for (let i = 0; i < validBlocs.length; i++) {
    for (let j = i + 1; j < validBlocs.length; j++) {
      const blocA = validBlocs[i];
      const blocB = validBlocs[j];

      const totalSeats = blocA.seats + blocB.seats;
      if (totalSeats < 61) continue;

      const diff = Math.abs(blocA.seats - blocB.seats);
      if (diff > 2) continue; // פער פריטטי של עד 2 מנדטים

      const overlap = blocA.parties.some((pa) =>
        blocB.parties.some((pb) => pa.id === pb.id)
      );
      if (overlap) continue;

      let tabooScore = 0;
      const brokenDetails = [];
      let totalInterGap = 0;
      let interPairs = 0;

      for (const pa of blocA.parties) {
        for (const pb of blocB.parties) {
          const rAB = getRelation(pa.id, pb.id);
          const rBA = getRelation(pb.id, pa.id);

          [[pa, pb, rAB], [pb, pa, rBA]].forEach(([fromP, toP, val]) => {
            if (val >= 7) {
              tabooScore += 2;
              brokenDetails.push(`${fromP.name} בחרם רמה 7 על ${toP.name}`);
            } else if (val === 6) {
              tabooScore += 1;
              brokenDetails.push(`${fromP.name} בחרם רמה 6 על ${toP.name}`);
            } else if (val === 5) {
              tabooScore += 0.66;
              brokenDetails.push(`${fromP.name} בחרם רמה 5 על ${toP.name}`);
            }
          });

          totalInterGap += calcDistance(pa, pb);
          interPairs++;
        }
      }

      const avgInterGap = interPairs > 0 ? Number((totalInterGap / interPairs).toFixed(2)) : 0;
      const allCoalitionParties = [...blocA.parties, ...blocB.parties];

      if (tabooScore <= 4) {
        parityCoalitions.push({
          id: allCoalitionParties.map((p) => p.id).sort().join('-'),
          parties: allCoalitionParties,
          blocA,
          blocB,
          blockA: blocA.parties,
          blockB: blocB.parties,
          seats: totalSeats,
          totalSeats,
          diff,
          parityDiff: diff,
          taboosBroken: Number(tabooScore.toFixed(2)),
          brokenDetails,
          gap: avgInterGap,
          totalDistance: Number(totalInterGap.toFixed(2)),
          averageDistance: avgInterGap,
          isParity: true,
        });
      }
    }
  }

  parityCoalitions.sort((a, b) => a.taboosBroken - b.taboosBroken || a.diff - b.diff || a.gap - b.gap);

  const finalParity = parityCoalitions.slice(0, 20);
  finalParity.type = 'parity';
  finalParity.results = finalParity;

  return finalParity;
}

// ייצוא כל השמות כדי למנוע שגיאות ייבוא מכל קובץ שהוא
export const findCoalitions = findBestCoalitions;
export const findParityCoalitions = findBestCoalitions;
export default findBestCoalitions;