// components/5_coalition/CoalitionCard.jsx
'use client';

export default function CoalitionCard({ coalition, rank }) {
  if (!coalition) return null;

  return (
    <div className="bg-white rounded-2xl p-4 sm:p-5 border border-sky-200 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-sky-100 pb-3 mb-3">
        <div className="flex items-center gap-2">
          <span className="flex items-center justify-center w-7 h-7 rounded-full bg-sky-700 text-white text-xs font-black">
            #{rank}
          </span>
          <span className="text-sm sm:text-base font-extrabold text-slate-800">
            {coalition.totalSeats} מנדטים
          </span>
          <span className="text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full font-bold">
            רוב יציב
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-semibold">סך פערים מצטבר:</span>
          <span className="bg-sky-50 text-sky-900 border border-sky-300 font-black px-2.5 py-1 rounded-xl text-sm">
            {coalition.totalDistance} נק'
          </span>
          <span className="text-[11px] text-slate-400">
            (ממוצע {coalition.averageDistance} לזוג)
          </span>
        </div>
      </div>

      {/* רשימת המפלגות בקואליציה */}
      <div className="flex flex-wrap gap-2">
        {coalition.parties.map((party) => (
          <span
            key={party.id}
            className="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors"
          >
            <span>{party.name}</span>
            <span className="text-sky-700 text-[11px] font-extrabold">({party.seats})</span>
          </span>
        ))}
      </div>
    </div>
  );
}