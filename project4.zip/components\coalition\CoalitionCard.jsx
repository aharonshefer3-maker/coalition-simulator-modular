// components/coalition/CoalitionCard.jsx
'use client';

import React from 'react';

export default function CoalitionCard({ coalition, rank }) {
  if (!coalition) return null;

  // חילוץ בטוח של הערכים עם תמיכה בכל שמות השדות האפשריים
  const totalScore = coalition.totalScore ?? coalition.score ?? coalition.ideologicalGap ?? 0;
  const avgScore = coalition.avgRelation ?? (coalition.partyCount > 1 ? (totalScore / coalition.partyCount).toFixed(1) : totalScore);
  const totalSeats = coalition.totalSeats ?? 0;
  const parties = coalition.parties ?? [];

  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 text-slate-800 space-y-4">
      {/* שורת הניקוד והפערים */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-slate-700">סך פערים מצטבר:</span>
          <span className="bg-sky-50 text-sky-700 border border-sky-300 font-extrabold px-3 py-0.5 rounded-full text-sm">
            {totalScore} נק׳
          </span>
          <span className="text-xs text-slate-400">
            ({avgScore} ממוצע לזוג)
          </span>
        </div>

        <div className="flex items-center gap-2">
          {coalition.isParity && (
            <span className="bg-purple-100 text-purple-800 border border-purple-300 text-xs px-2.5 py-1 rounded-lg font-bold">
              ⚖️ {coalition.parityType || 'פריטטית'}
            </span>
          )}
          <span className="bg-slate-100 text-slate-700 font-bold px-3 py-1 rounded-xl text-xs border border-slate-200">
            {totalSeats} מנדטים
          </span>
        </div>
      </div>

      {/* תגיות המפלגות בקואליציה */}
      <div className="flex flex-wrap gap-2 pt-1 border-t border-slate-100">
        {parties.map((p) => (
          <div
            key={p.id}
            className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-3 py-1 rounded-xl text-xs font-semibold text-slate-700"
          >
            <span
              className="w-2.5 h-2.5 rounded-full inline-block"
              style={{ backgroundColor: p.color || '#0284c7' }}
            />
            <span>{p.name}</span>
            <span className="bg-white border border-slate-200 text-slate-500 px-1.5 py-0.2 rounded-md font-mono text-[11px]">
              {p.seats}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}