// utils/coalitionEngine.js

/**
 * חילוץ רשימת הערכים המספריים של הצירים, ללא תלות אם pos הוא מערך או אובייקט
 */
function extractPositionValues(pos) {
  if (!pos) return [];
  if (Array.isArray(pos)) {
    return pos.map((v) => (v == null || v === '' || isNaN(v) ? 0 : Number(v)));
  }
  if (typeof pos === 'object') {
    return Object.values(pos).map((v) => (v == null || v === '' || isNaN(v) ? 0 : Number(v)));
  }
  return [];
}

/**
 * חישוב מרחק עמדות כולל (L1 / סכום ערכים מוחלטים) בין שתי מפלגות
 */
function calculateIdeologicalDistance(partyA, partyB) {
  const valsA = extractPositionValues(partyA.pos);
  const valsB = extractPositionValues(partyB.pos);
  const length = Math.max(valsA.length, valsB.length);

  if (length === 0) return 0;

  let sumDiff = 0;
  for (let i = 0; i < length; i++) {
    const a = valsA[i] ?? 0;
    const b = valsB[i] ?? 0;
    sumDiff += Math.abs(a - b);
  }
  return sumDiff;
}

/**
 * חילוץ מדד היחסים בין שתי מפלגות (1=הסכמה/שותפות מלאה, 7=עוינות/וטו)
 */
function getPairRelation(p1Id, p2Id, relations = {}, asymmetricPairs = {}) {
  const key1 = `${p1Id}-${p2Id}`;
  const key2 = `${p2Id}-${p1Id}`;

  // אם הוגדר כיחס א-סימטרי
  if (asymmetricPairs[key1] && relations[key1] !== undefined) {
    const val = Number(relations[key1]);
    return isNaN(val) ? 4 : val;
  }
  if (asymmetricPairs[key2] && relations[key2] !== undefined) {
    const val = Number(relations[key2]);
    return isNaN(val) ? 4 : val;
  }

  // יחס סימטרי רגיל
  const val = relations[key1] ?? relations[key2];
  const numVal = Number(val);
  return !isNaN(numVal) && val !== undefined ? numVal : 4;
}

/**
 * בדיקה האם קיים וטו (ערך 7 או יחס שנאה מוחלט) בין שתי שותפות
 */
function hasVeto(parties, relations, asymmetricPairs) {
  for (let i = 0; i < parties.length; i++) {
    for (let j = i + 1; j < parties.length; j++) {
      const p1 = parties[i].id;
      const p2 = parties[j].id;

      const rel1 = relations[`${p1}-${p2}`];
      const rel2 = relations[`${p2}-${p1}`];

      if (Number(rel1) === 7 || Number(rel2) === 7 || Number(rel1) === -1 || Number(rel2) === -1) {
        return true;
      }
    }
  }
  return false;
}

/**
 * חישוב ציונים משוקללים: פער עמדות + סך יחסי שנאה (1+1 עדיף על 7+7)
 */
function calculateCoalitionScores(coalitionParties, relations, asymmetricPairs) {
  let ideologicalGap = 0;
  let relationsScore = 0;
  let pairCount = 0;

  for (let i = 0; i < coalitionParties.length; i++) {
    for (let j = i + 1; j < coalitionParties.length; j++) {
      const p1 = coalitionParties[i];
      const p2 = coalitionParties[j];

      ideologicalGap += calculateIdeologicalDistance(p1, p2);
      relationsScore += getPairRelation(p1.id, p2.id, relations, asymmetricPairs);
      pairCount++;
    }
  }

  // ציון סופי - ככל שנמוך יותר, הקואליציה הומוגנית והרמונית יותר
  const totalScore = ideologicalGap + relationsScore;

  return {
    ideologicalGap,
    relationsScore,
    totalScore,
    avgRelation: pairCount > 0 ? Number((relationsScore / pairCount).toFixed(2)) : 0,
  };
}

/**
 * בדיקת פריטטיות (ממשלת 60 שוויונית או חלוקה פנימית שווה)
 */
function checkParity(coalitionParties, totalSeats) {
  if (totalSeats === 60) {
    return { isParity: true, type: 'תיקו פריטטי (60 מנדטים)' };
  }

  const halfSeats = totalSeats / 2;
  if (Number.isInteger(halfSeats)) {
    const canSplitEqually = (arr, target) => {
      const dp = new Set([0]);
      for (const p of arr) {
        const next = new Set(dp);
        for (const sum of dp) {
          const s = sum + Number(p.seats);
          if (s === target) return true;
          if (s < target) next.add(s);
        }
        for (const val of next) dp.add(val);
      }
      return false;
    };

    if (canSplitEqually(coalitionParties, halfSeats)) {
      return { isParity: true, type: `פריטטית פנימית (${halfSeats}/${halfSeats})` };
    }
  }

  return { isParity: false, type: null };
}

/**
 * מנוע חיפוש הקואליציות עם שמירה ב-Set ומניעת כפילויות
 */
export function findBestCoalitions(
  parties = [],
  relations = {},
  asymmetricPairs = {},
  minSeats = 60
) {
  if (!Array.isArray(parties) || parties.length === 0) return [];

  // סינון מפלגות פעילות בעלות מנדטים בלבד
  const activeParties = parties.filter((p) => Number(p.seats) > 0);

  const seenSignatures = new Set();
  const results = [];

  function generateCombinations(startIndex, current, currentSeats) {
    // קואליציה חוקית (60 ומעלה)
    if (currentSeats >= minSeats) {
      // חתימה ייחודית מבוססת מזהי מפלגות ממוינים אלפביתית
      const signature = current
        .map((p) => p.id)
        .sort()
        .join('|');

      if (!seenSignatures.has(signature)) {
        seenSignatures.add(signature);

        if (!hasVeto(current, relations, asymmetricPairs)) {
          const { ideologicalGap, relationsScore, totalScore, avgRelation } =
            calculateCoalitionScores(current, relations, asymmetricPairs);

          const parityInfo = checkParity(current, currentSeats);

          results.push({
            id: signature,
            parties: [...current],
            totalSeats: currentSeats,
            partyCount: current.length,
            ideologicalGap,
            relationsScore,
            totalScore,
            avgRelation,
            isParity: parityInfo.isParity,
            parityType: parityInfo.type,
          });
        }
      }
    }

    for (let i = startIndex; i < activeParties.length; i++) {
      const party = activeParties[i];
      const seats = Number(party.seats) || 0;

      current.push(party);
      generateCombinations(i + 1, current, currentSeats + seats);
      current.pop();
    }
  }

  generateCombinations(0, [], 0);

  // מיון מחמיר לפי הציון המשוקלל הנמוך ביותר (אידיאולוגיה + יחסים)
  return results.sort((a, b) => {
    if (a.totalScore !== b.totalScore) {
      return a.totalScore - b.totalScore;
    }
    if (a.totalSeats !== b.totalSeats) {
      return a.totalSeats - b.totalSeats;
    }
    return a.partyCount - b.partyCount;
  });
}